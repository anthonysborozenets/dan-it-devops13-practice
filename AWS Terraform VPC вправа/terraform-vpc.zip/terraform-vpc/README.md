# AWS Terraform VPC — bastion / jump-host

Власна VPC + публічний EC2 (bastion) + приватний EC2, доступний лише з bastion.

## Архітектура

```
Internet
   │
   ▼
[Internet Gateway]
   │
┌──┴───────────────── VPC 10.0.0.0/16 ─────────────────┐
│                                                       │
│  Public subnet 10.0.1.0/24       Private subnet 10.0.2.0/24
│  ┌───────────────┐               ┌───────────────┐    │
│  │ public-ec2    │  ── SSH ──▶   │ private-ec2   │    │
│  │ (bastion)     │               │ (no public IP)│    │
│  │ public IP     │               └──────┬────────┘    │
│  └──────┬────────┘                      │             │
│         │                          0.0.0.0/0          │
│      0.0.0.0/0 → IGW                    │             │
│         │                          [NAT Gateway] ◀────┘
│         ▼                               │   (в публічній підмережі)
└─────────────────────────────────────────┘
                                          ▼
                                       Internet (ping google.com)
```

## Передумови
- Terraform >= 1.5
- AWS CLI з налаштованими credentials (`aws configure`)
- Регіон: eu-central-1

## Крок 0. Підготовка
```bash
cp terraform.tfvars.example terraform.tfvars
# Дізнатися свій IP:
curl ifconfig.me
# Вставити його у terraform.tfvars як my_ip = "1.2.3.4/32"
```

## Крок 1. Розгортання (скрін №2 — створення всього для доступу в інтернет)
```bash
terraform init
terraform plan
terraform apply        # вводимо yes
```
Після apply дивимось outputs (IP-адреси, готова SSH-команда).

## Крок 2. SSH у публічний EC2 (скрін №3)
```bash
ssh -i tf-vpc-demo-key.pem ec2-user@<PUBLIC_IP>
```

## Крок 3. SSH з публічного у приватний EC2 (скрін №4)
Спосіб А — SSH agent forwarding (рекомендований, ключ не копіюється на bastion):
```bash
# на локальній машині:
ssh-add tf-vpc-demo-key.pem
ssh -A -i tf-vpc-demo-key.pem ec2-user@<PUBLIC_IP>
# вже на bastion:
ssh ec2-user@<PRIVATE_INSTANCE_PRIVATE_IP>
```
Спосіб Б — простіший (скопіювати ключ на bastion):
```bash
scp -i tf-vpc-demo-key.pem tf-vpc-demo-key.pem ec2-user@<PUBLIC_IP>:~/
ssh -i tf-vpc-demo-key.pem ec2-user@<PUBLIC_IP>
chmod 400 tf-vpc-demo-key.pem
ssh -i tf-vpc-demo-key.pem ec2-user@<PRIVATE_INSTANCE_PRIVATE_IP>
```

## Крок 4. Ping google.com з приватного EC2 (скрін №5)
```bash
# вже всередині приватного інстансу:
ping -c 4 google.com
```
Працює завдяки NAT Gateway. Якщо NAT не створено — пінгу не буде.

## Крок 5. Видалення інфраструктури (скрін №6)
```bash
exit          # вийти з приватного
exit          # вийти з bastion
terraform destroy   # вводимо yes
```

## Важливо про вартість
- NAT Gateway та Elastic IP — НЕ входять у free tier (~$0.045/год + трафік).
- Не забудь зробити `terraform destroy` одразу після зняття скрінів.
