# Terraform + Ansible: 2x EC2 з Nginx у Docker Compose

Terraform піднімає 2 EC2 і автоматично генерує Ansible inventory.
Ansible playbook ставить Docker + Docker Compose і запускає Nginx у контейнері.

## Файли
```
tf-ansible/
├── providers.tf        # provider aws, eu-central-1
├── variables.tf        # my_ip, instance_count (=2) тощо
├── main.tf             # key, SG, 2x EC2, генерація inventory.ini
├── inventory.tmpl      # шаблон, з якого Terraform робить inventory.ini
├── outputs.tf          # IP та URL
├── ansible.cfg         # щоб ansible сам бачив inventory і ключ
└── playbook.yml        # docker → compose → nginx
```

## Передумови
- Terraform і AWS CLI вже налаштовані (з минулих вправ)
- Ansible: `brew install ansible`  (перевірка: `ansible --version`)

## Крок 1. Підготовка
```bash
curl ifconfig.me                       # дізнатись свій IP
echo 'my_ip = "ТВІЙ_IP/32"' > terraform.tfvars
```

## Крок 2. Terraform — підняти EC2 (скрін розгортання)
```bash
terraform init
terraform apply        # yes
```
Після apply поряд зʼявляться `tf-ansible-key.pem` і `inventory.ini`
(його згенерував Terraform — це пункт 2 здачі).

## Крок 3. Перевірити звʼязок з машинами
```bash
ansible web -m ping
```
Має бути `SUCCESS` для обох IP. Якщо ні — зачекай ~30 сек (машини ще вантажаться) і повтори.

## Крок 4. Ansible — розгорнути Nginx (скрін роботи Ansible)
```bash
ansible-playbook playbook.yml
```
У підсумку `PLAY RECAP` має показати `ok` / `changed` і `failed=0` для обох хостів.

## Крок 5. Перевірка в браузері (скрін результату)
Подивись IP:
```bash
terraform output urls
```
Відкрий обидва `http://IP` — побачиш дефолтну сторінку Nginx.

## Крок 6. Видалення (скрін видалення)
```bash
terraform destroy     # yes
```
